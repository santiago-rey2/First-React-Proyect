<?php return array('dependencies' => array(), 'version' => '56e43870530735931612');
