<?php return array('dependencies' => array(), 'version' => '9446f3f4b502d70f1308');
