=== Sovy ===
Requires at least: 6.2
Tested up to: 6.6
Requires PHP: 7.4

== Description ==
Sovy is a clean and modern WordPress theme specially designed for restaurants, cafes, bars, culinary ventures, and any food-related business. Fully compatible with the WordPress block editor, Sovy makes customization easy and provides all the essential tools to build a website that perfectly represents your brand.

== Changelog ==
= Version 1.0.0 =
* First release