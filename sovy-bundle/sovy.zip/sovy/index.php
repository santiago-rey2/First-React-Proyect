<?php
// Block themes no longer required index.php
// All templates can be directly edited through Appearance->Editor